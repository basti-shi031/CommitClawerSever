def init(i):
    if i == 0:
        return 1, 1
    else:
        return None,None


a,b = init(0)
c,d = init(1)
print(c,d)
