debug = True


def p(content):
    if debug:
        print(content)
